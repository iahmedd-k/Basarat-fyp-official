#!/usr/bin/env python3
"""
psx_kse100.py - daily scraper for KSE-100 company profile + fundamentals.

Source: the public PSX Data Portal (https://dps.psx.com.pk). PSX has no official
API, so this reads the same HTML pages the website shows. Run it ONCE A DAY
(after the market closes) - the data does not change faster than that.

Request budget for a full run: 1 (market-watch) + ~100 (one page per company).

Usage
-----
  python psx_kse100.py --limit 3                 # testing mode: first 3 stocks
  python psx_kse100.py --symbols HBL,OGDC,LUCK   # testing mode: chosen stocks
  python psx_kse100.py                           # full KSE-100 run (~3 minutes)
  python psx_kse100.py --refresh                 # ignore today's cached pages

Outputs (in ./output): kse100_fundamentals_<date>.json / .csv, kse100_latest.json
"""
from __future__ import annotations

import argparse
import csv
import json
import logging
import os
import random
import re
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests
from bs4 import BeautifulSoup, Tag

BASE_URL = "https://dps.psx.com.pk"
PKT = timezone(timedelta(hours=5))  # Pakistan Standard Time, no DST
INDEX_CODE = "KSE100"
log = logging.getLogger("psx_kse100")

# Fields users asked for that the PSX portal does NOT publish on company pages.
NOT_ON_PSX = [
    "total_assets", "total_liabilities", "current_ratio", "quick_ratio", "roe",
    "roa", "debt_to_equity", "book_value_per_share", "free_cash_flow",
]


# --------------------------------------------------------------------------- errors
class ScraperError(Exception):
    pass


class UnknownSymbol(ScraperError):
    """Page loaded but is not a real company page (delisted / renamed symbol)."""


class FetchFailed(ScraperError):
    """One request failed after its retries. The run continues with the next stock."""


class StopRun(ScraperError):
    """Stop the whole run now. We never retry around this - that is how you get blocked."""


class CoolingDown(StopRun):
    """PSX pushed back (429/403) or too many consecutive failures."""


class BudgetExceeded(StopRun):
    """Local safety fuse: more requests than a normal run should ever need."""


# --------------------------------------------------------------------------- number parsing
_BLANKS = {"", "-", "\u2014", "\u2013", "n/a", "na", "none"}
_RANGE_NUM = re.compile(r"\d[\d,]*\.?\d*")


def parse_number(text) -> float | None:
    """'1,234.50' -> 1234.5 ; '(0.15)' -> -0.15 ; '12%' -> 12.0 ; '-' -> None."""
    if text is None:
        return None
    t = re.sub(r"^rs\.?\s*", "", str(text).replace("\xa0", " ").strip(), flags=re.I)
    if t.lower() in _BLANKS:
        return None
    negative = t.startswith("(") and t.endswith(")")
    t = t.strip("()").replace(",", "").replace("%", "").strip()
    try:
        value = float(t)
    except ValueError:
        return None
    return -value if negative else value


def parse_int(text) -> int | None:
    v = parse_number(text)
    return None if v is None else int(round(v))


def parse_range(text) -> tuple[float | None, float | None]:
    nums = [parse_number(x) for x in _RANGE_NUM.findall(text or "")]
    if len(nums) >= 2:
        return nums[0], nums[1]
    return None, None


def _clean_label(text: str) -> str:
    """Drop footnote markers: '52-WEEK RANGE ^' -> '52-WEEK RANGE'."""
    return re.sub(r"[\s*^]+$", "", " ".join(text.split()))


# --------------------------------------------------------------------------- constituents
def kse100_from_market_watch(html: str, index_code: str = INDEX_CODE) -> list[dict]:
    """Rows of /market-watch whose 'LISTED IN' column contains the index code.

    Exact token match matters: 'KSE100PR' (price-return index) must not match 'KSE100'.
    """
    soup = BeautifulSoup(html, "lxml")
    table = soup.select_one("table")
    if table is None:
        raise ScraperError("market-watch: no table found (page layout changed?)")
    headers = [th.get_text(" ", strip=True).upper() for th in table.select("thead th")]
    try:
        listed_idx = next(i for i, h in enumerate(headers) if "LISTED IN" in h)
    except StopIteration:
        raise ScraperError(f"market-watch: no 'LISTED IN' column in {headers}") from None
    sector_idx = next((i for i, h in enumerate(headers) if h == "SECTOR"), None)

    out = []
    for tr in table.select("tbody tr"):
        tds = tr.find_all("td")
        if len(tds) <= listed_idx:
            continue
        link = tr.select_one("a.tbl__symbol")
        symbol = (link.get_text(strip=True) if link else tds[0].get("data-order", "")).strip()
        if not symbol:
            continue
        tokens = {t.strip() for t in tds[listed_idx].get_text(" ", strip=True).split(",")}
        if index_code in tokens:
            out.append({
                "symbol": symbol.upper(),
                "name_hint": link.get("data-title") if link else None,
                "sector_code": tds[sector_idx].get_text(strip=True) if sector_idx is not None else None,
            })
    return out


def symbols_from_index_page(html: str) -> list[str]:
    """Fallback: company links on /indices/KSE100. (Layout not verified against a recording.)"""
    soup = BeautifulSoup(html, "lxml")
    seen: dict[str, None] = {}
    for a in soup.select('a[href^="/company/"]'):
        sym = a["href"].rsplit("/", 1)[-1].strip().upper()
        if sym and sym != "PAYOUTS":
            seen[sym] = None
    return list(seen)


# --------------------------------------------------------------------------- company page
def _section(soup: BeautifulSoup, title: str) -> Tag | None:
    for t in soup.select(".section__title"):
        if t.get_text(strip=True) == title:
            return t.find_parent(class_="section")
    return None


def _stat_pairs(scope: Tag | None) -> list[tuple[str, str]]:
    if scope is None:
        return []
    return [
        (_clean_label(lab.get_text(" ", strip=True)), val.get_text(" ", strip=True))
        for lab, val in zip(scope.select(".stats_label"), scope.select(".stats_value"))
    ]


def _parse_profile(sec: Tag | None) -> dict:
    out = {"business_description": None, "key_people": [], "address": None, "website": None,
           "registrar": None, "auditor": None, "fiscal_year_end": None}
    if sec is None:
        return out
    simple = {"BUSINESS DESCRIPTION": "business_description", "ADDRESS": "address",
              "REGISTRAR": "registrar", "AUDITOR": "auditor", "FISCAL YEAR END": "fiscal_year_end"}
    for head in sec.select(".item__head"):
        label = head.get_text(" ", strip=True).upper()
        content: list[Tag] = []
        for sib in head.next_siblings:
            if isinstance(sib, Tag):
                if "item__head" in (sib.get("class") or []):
                    break
                content.append(sib)
        text = " ".join(c.get_text(" ", strip=True) for c in content).strip() or None
        if label in simple:
            out[simple[label]] = text
        elif label == "WEBSITE":
            href = next((a.get("href") for c in content for a in c.select("a[href]")), None)
            out["website"] = href or text
        elif label == "KEY PEOPLE":
            for c in content:
                for tr in c.select("tr"):
                    cells = [td.get_text(" ", strip=True) for td in tr.select("td")]
                    if cells and cells[0]:
                        out["key_people"].append(
                            {"name": cells[0], "role": cells[1] if len(cells) > 1 else None})
    return out


def _parse_equity(sec: Tag | None) -> dict:
    out = {"market_cap_pkr": None, "shares": None, "free_float": None, "free_float_pct": None}
    seen_ff = False
    for label, value in _stat_pairs(sec):
        if label.startswith("Market Cap"):
            thousands = parse_number(value)  # published in PKR thousands
            out["market_cap_pkr"] = None if thousands is None else round(thousands * 1000, 2)
        elif label == "Shares":
            out["shares"] = parse_int(value)
        elif label == "Free Float":  # appears twice: absolute shares, then percent
            if not seen_ff:
                out["free_float"], seen_ff = parse_int(value), True
            else:
                out["free_float_pct"] = parse_number(value)
    return out


def _parse_period_table(table: Tag | None) -> dict:
    """{'periods': ['2025', ...], 'rows': {'EPS': {'2025': 42.6, ...}}} - newest period first."""
    if table is None:
        return {"periods": [], "rows": {}}
    periods = [th.get_text(strip=True) for th in table.select("thead th")][1:]
    rows: dict[str, dict] = {}
    for tr in table.select("tbody tr"):
        tds = tr.select("td")
        if len(tds) < 2:
            continue
        label = tds[0].get_text(" ", strip=True)
        rows[label] = dict(zip(periods, (parse_number(td.get_text(strip=True)) for td in tds[1:])))
    return {"periods": periods, "rows": rows}


_REVENUE_LABELS = ["sales", "net sales", "revenue", "net revenue", "turnover",
                   "mark-up earned", "net premium", "gross premium"]


def _headline(fin: dict) -> dict:
    """Pick revenue / net profit / EPS for the newest period, keeping the label we matched."""
    out = {"period": None, "revenue": None, "revenue_label": None, "net_profit": None, "eps": None}
    if not fin["periods"]:
        return out
    period = fin["periods"][0]
    out["period"] = period
    by_lower = {k.lower(): k for k in fin["rows"]}
    rev_key = next((by_lower[l] for l in _REVENUE_LABELS if l in by_lower), None)
    if rev_key:
        out["revenue"], out["revenue_label"] = fin["rows"][rev_key].get(period), rev_key
    np_key = next((k for lk, k in by_lower.items() if lk.startswith("profit after tax")), None)
    if np_key:
        out["net_profit"] = fin["rows"][np_key].get(period)
    if "eps" in by_lower:
        out["eps"] = fin["rows"][by_lower["eps"]].get(period)
    return out


def parse_company_page(html: str, symbol: str) -> dict:
    soup = BeautifulSoup(html, "lxml")
    if soup.select_one(".company__quote") is None:
        raise UnknownSymbol(symbol)

    def text(sel: str) -> str | None:
        el = soup.select_one(f".company__quote {sel}")
        return el.get_text(" ", strip=True) if el else None

    reg = dict(_stat_pairs(soup.select_one('.tabs__panel[data-name="REG"]')))
    w52_low, w52_high = parse_range(reg.get("52-WEEK RANGE"))
    fin_sec = _section(soup, "Financials")
    annual = _parse_period_table(
        fin_sec.select_one('.tabs__panel[data-name="Annual"] table') if fin_sec else None)
    quarterly = _parse_period_table(
        fin_sec.select_one('.tabs__panel[data-name="Quarterly"] table') if fin_sec else None)
    ratios_sec = _section(soup, "Ratios")
    ratios = _parse_period_table(ratios_sec.select_one("table") if ratios_sec else None)

    return {
        "symbol": symbol,
        "company_name": text(".quote__name"),
        "sector": text(".quote__sector"),
        "price": parse_number(text(".quote__close")),
        "price_as_of": re.sub(r"^[\s^]*As of\s*", "", text(".quote__date") or "") or None,
        "ldcp": parse_number(reg.get("LDCP")),
        "pe_ratio_ttm": parse_number(reg.get("P/E Ratio (TTM)")),
        "week52_low": w52_low,
        "week52_high": w52_high,
        **_parse_profile(_section(soup, "Company Profile")),
        **_parse_equity(_section(soup, "Equity Profile")),
        "financials": {
            "units": "PKR thousands (000s) except EPS (PKR per share)",
            "annual": annual,
            "quarterly": quarterly,
        },
        "ratios": ratios,
        "headline_annual": _headline(annual),
        "headline_quarterly": _headline(quarterly),
    }


# --------------------------------------------------------------------------- polite HTTP
class PoliteClient:
    """requests wrapper built to stay unblocked.

    - one request at a time, minimum interval + random jitter between request starts
    - keep-alive session, honest User-Agent, no UA/proxy rotation
    - exponential backoff on timeouts/5xx; on 429/403 STOP (never retry around a rejection)
    - circuit breaker: N failed fetches in a row stops the run
    - hard request budget per run
    - on-disk cache per day: re-running the same day costs zero requests (also = resume)
    """

    def __init__(self, base_url=BASE_URL, cache_dir="cache", min_interval=1.5, jitter=0.5,
                 timeout=(10, 30), retries=3, max_requests=150, max_consecutive_failures=5,
                 user_agent=None, backoff_base=5.0, refresh=False, sleep=time.sleep):
        self.base_url = base_url.rstrip("/")
        self.today = datetime.now(PKT).date().isoformat()
        self.cache_dir = Path(cache_dir) / self.today
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.min_interval, self.jitter, self.timeout = min_interval, jitter, timeout
        self.retries, self.max_requests = retries, max_requests
        self.max_consecutive_failures = max_consecutive_failures
        self.backoff_base, self.refresh, self._sleep = backoff_base, refresh, sleep
        self.requests_made = self.cache_hits = self.consecutive_failures = 0
        self._last_start = 0.0
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": user_agent or os.environ.get(
                "PSX_USER_AGENT", "psx-kse100-scraper/1.0 (personal research; daily run)"),
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": self.base_url + "/",
        })

    def _throttle(self):
        wait = self.min_interval + random.uniform(0, self.jitter) - (time.monotonic() - self._last_start)
        if wait > 0:
            self._sleep(wait)
        self._last_start = time.monotonic()

    def _reset_connection(self):
        """Drop keep-alive connections. PSX's DNS rotates between nodes, so a fresh
        connection can land on a healthy one after a node answers 404 for data routes."""
        self.session.close()

    def get(self, path: str, cache_key: str, *, not_found_ok: bool = False) -> str | None:
        """Return page HTML. None only if not_found_ok and the server says 404."""
        cached = self.cache_dir / f"{cache_key}.html"
        if cached.exists() and cached.stat().st_size > 0 and not self.refresh:
            self.cache_hits += 1
            return cached.read_text(encoding="utf-8")

        url = self.base_url + path
        reason = "unknown"
        for attempt in range(1, self.retries + 1):
            if self.requests_made >= self.max_requests:
                raise BudgetExceeded(f"request budget of {self.max_requests} reached")
            self._throttle()
            self.requests_made += 1
            retry_after = None
            try:
                r = self.session.get(url, timeout=self.timeout)
            except (requests.ConnectionError, requests.Timeout) as exc:
                reason = type(exc).__name__
                self._reset_connection()
            else:
                code = r.status_code
                if code == 200 and r.text.strip():
                    self.consecutive_failures = 0
                    tmp = cached.with_suffix(".tmp")
                    tmp.write_text(r.text, encoding="utf-8")
                    tmp.replace(cached)
                    return r.text
                if code in (429, 403):
                    raise CoolingDown(f"HTTP {code} on {path}: PSX is pushing back - stopping the run")
                if code == 404 and not_found_ok:
                    self.consecutive_failures = 0
                    return None
                reason = f"HTTP {code}"
                if code == 404:
                    self._reset_connection()  # possibly a node that doesn't serve data routes
                elif code < 500:
                    break  # other 4xx: retrying will not help
                ra = r.headers.get("Retry-After", "")
                retry_after = min(float(ra), 120.0) if ra.isdigit() else None
            if attempt < self.retries:
                delay = retry_after or min(60.0, self.backoff_base * 3 ** (attempt - 1))
                delay += random.uniform(0, 2)
                log.warning("%s on %s (attempt %d/%d) - waiting %.0fs", reason, path, attempt,
                            self.retries, delay)
                self._sleep(delay)

        self.consecutive_failures += 1
        if self.consecutive_failures >= self.max_consecutive_failures:
            raise CoolingDown(f"{self.consecutive_failures} fetches failed in a row (last: {reason})")
        raise FetchFailed(f"{path}: {reason}")


# --------------------------------------------------------------------------- lock + output
class RunLock:
    """Prevent two overlapping runs (e.g. cron firing while a manual test is running)."""

    def __init__(self, path: Path, stale_after_s: int = 6 * 3600):
        self.path, self.stale = path, stale_after_s

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists() and time.time() - self.path.stat().st_mtime > self.stale:
            self.path.unlink()
        try:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise ScraperError(f"another run seems active (lock file {self.path}); "
                               "delete it if that is wrong") from None
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
        return self

    def __exit__(self, *exc):
        self.path.unlink(missing_ok=True)


def _write_atomic(path: Path, text: str):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)


def _flat_row(s: dict) -> dict:
    ha = s["headline_annual"]
    ratio_rows = s["ratios"]["rows"]
    newest = s["ratios"]["periods"][0] if s["ratios"]["periods"] else None

    def ratio(label_start: str):
        key = next((k for k in ratio_rows if k.lower().startswith(label_start)), None)
        return ratio_rows[key].get(newest) if key and newest else None

    return {
        "symbol": s["symbol"], "company_name": s["company_name"], "sector": s["sector"],
        "price": s["price"], "price_as_of": s["price_as_of"], "ldcp": s["ldcp"], "pe_ratio_ttm": s["pe_ratio_ttm"],
        "week52_low": s["week52_low"], "week52_high": s["week52_high"],
        "market_cap_pkr": s["market_cap_pkr"], "shares": s["shares"],
        "free_float": s["free_float"], "free_float_pct": s["free_float_pct"],
        "website": s["website"], "fiscal_year_end": s["fiscal_year_end"],
        "latest_annual_period": ha["period"], "revenue_thousands": ha["revenue"],
        "revenue_label": ha["revenue_label"], "net_profit_thousands": ha["net_profit"],
        "eps": ha["eps"], "net_profit_margin_pct": ratio("net profit margin"),
        "eps_growth_pct": ratio("eps growth"), "peg": ratio("peg"),
        "business_description": s["business_description"],
    }


def _completeness(stocks: list[dict]) -> dict:
    checks = {
        "business_description": lambda s: s["business_description"],
        "website": lambda s: s["website"],
        "market_cap_pkr": lambda s: s["market_cap_pkr"],
        "shares": lambda s: s["shares"],
        "pe_ratio_ttm": lambda s: s["pe_ratio_ttm"],
        "annual_eps": lambda s: s["headline_annual"]["eps"],
        "annual_net_profit": lambda s: s["headline_annual"]["net_profit"],
        "annual_revenue": lambda s: s["headline_annual"]["revenue"],
        "ratios": lambda s: s["ratios"]["rows"],
    }
    return {k: f"{sum(1 for s in stocks if fn(s) not in (None, '', {}, []))}/{len(stocks)}"
            for k, fn in checks.items()}


# --------------------------------------------------------------------------- orchestration
def run_daily(*, out_dir="output", cache_dir="cache", base_url=BASE_URL, limit=None,
              only_symbols=None, refresh=False, crosscheck=False, min_expected=90,
              client: PoliteClient | None = None) -> dict:
    started = time.time()
    out, cache = Path(out_dir), Path(cache_dir)
    client = client or PoliteClient(base_url=base_url, cache_dir=cache, refresh=refresh)
    stocks, errors, status = [], [], "complete"

    with RunLock(cache / "run.lock"):
        # 1) constituents
        try:
            html = client.get("/market-watch", "_market_watch")
            members = kse100_from_market_watch(html)
            if len(members) < min_expected:
                log.warning("market-watch gave only %d KSE-100 symbols - trying /indices/%s",
                            len(members), INDEX_CODE)
                try:
                    idx = symbols_from_index_page(client.get(f"/indices/{INDEX_CODE}", "_index_page"))
                except FetchFailed as exc:
                    log.warning("fallback index page failed too: %s", exc)
                    idx = []
                known = {m["symbol"] for m in members}
                members += [{"symbol": s, "name_hint": None, "sector_code": None}
                            for s in idx if s not in known]
            elif crosscheck:
                idx = set(symbols_from_index_page(client.get(f"/indices/{INDEX_CODE}", "_index_page")))
                diff = idx ^ {m["symbol"] for m in members}
                if diff:
                    log.warning("cross-check: sources disagree on %d symbols: %s", len(diff), sorted(diff))
        except (StopRun, FetchFailed, ScraperError) as exc:
            raise ScraperError(f"could not get the KSE-100 list: {exc}") from exc
        if len(members) < min_expected and not only_symbols:
            raise ScraperError(f"only {len(members)} KSE-100 symbols found (expected ~100); "
                               "layout may have changed - refusing to write a partial universe")

        if only_symbols:
            wanted = [s.upper() for s in only_symbols]
            by_sym = {m["symbol"]: m for m in members}
            members = [by_sym.get(s, {"symbol": s, "name_hint": None, "sector_code": None}) for s in wanted]
        if limit:
            members = members[:limit]
        log.info("KSE-100 universe: %d symbols to scrape", len(members))

        # 2) one page per company
        for i, m in enumerate(members, 1):
            sym = m["symbol"]
            try:
                page = client.get(f"/company/{sym}", sym, not_found_ok=True)
                if page is None:
                    raise UnknownSymbol(sym)
                s = parse_company_page(page, sym)
                s["company_name"] = s["company_name"] or m["name_hint"]
                s["sector_code"] = m.get("sector_code")
                stocks.append(s)
                log.info("[%d/%d] %-8s ok", i, len(members), sym)
            except UnknownSymbol:
                errors.append({"symbol": sym, "error": "not a valid company page"})
                log.warning("[%d/%d] %-8s not a valid company page", i, len(members), sym)
            except FetchFailed as exc:
                errors.append({"symbol": sym, "error": str(exc)})
                log.warning("[%d/%d] %-8s FAILED: %s", i, len(members), sym, exc)
            except StopRun as exc:
                errors.append({"symbol": sym, "error": str(exc)})
                status = "aborted"
                log.error("ABORTING RUN: %s", exc)
                break
        if status != "aborted" and errors:
            status = "partial"

    # 3) write outputs (also on abort, so nothing already fetched is lost)
    date = client.today
    result = {
        "meta": {
            "date": date, "status": status, "source": BASE_URL, "index": INDEX_CODE,
            "stocks_ok": len(stocks), "stocks_failed": len(errors),
            "requests_made": client.requests_made, "cache_hits": client.cache_hits,
            "duration_s": round(time.time() - started, 1),
            "scraped_at": datetime.now(PKT).isoformat(timespec="seconds"),
            "not_available_on_psx": NOT_ON_PSX,
            "completeness": _completeness(stocks),
        },
        "stocks": stocks,
        "errors": errors,
    }
    if stocks:
        out.mkdir(parents=True, exist_ok=True)
        text = json.dumps(result, ensure_ascii=False, indent=2)
        _write_atomic(out / f"kse100_fundamentals_{date}.json", text)
        if status == "complete" and not (limit or only_symbols):
            _write_atomic(out / "kse100_latest.json", text)  # only full, clean runs
        rows = [_flat_row(s) for s in stocks]
        with open(out / f"kse100_fundamentals_{date}.csv", "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
    return result


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Daily KSE-100 profile + fundamentals scraper (PSX data portal)")
    ap.add_argument("--limit", type=int, help="testing mode: only the first N stocks")
    ap.add_argument("--symbols", help="testing mode: comma list, e.g. HBL,OGDC,LUCK")
    ap.add_argument("--refresh", action="store_true", help="ignore today's cached pages")
    ap.add_argument("--crosscheck", action="store_true", help="also compare list with /indices/KSE100 (+1 request)")
    ap.add_argument("--base-url", default=BASE_URL, help=argparse.SUPPRESS)
    ap.add_argument("--out", default="output")
    ap.add_argument("--cache", default="cache")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(message)s", datefmt="%H:%M:%S")
    try:
        res = run_daily(out_dir=a.out, cache_dir=a.cache, base_url=a.base_url, limit=a.limit, refresh=a.refresh,
                        only_symbols=a.symbols.split(",") if a.symbols else None,
                        crosscheck=a.crosscheck)
    except ScraperError as exc:
        log.error("%s", exc)
        return 2
    m = res["meta"]
    print(json.dumps(m, indent=2))
    return 0 if m["status"] == "complete" else 1


if __name__ == "__main__":
    sys.exit(main())

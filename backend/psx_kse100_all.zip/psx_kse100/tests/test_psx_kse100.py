"""Offline tests. Parser tests use REAL recorded PSX pages (tests/fixtures).
Network-behaviour tests use a local mock server that imitates PSX failure modes."""
import csv
import json
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import psx_kse100 as P  # noqa: E402

FIX = Path(__file__).parent / "fixtures"
HBL = (FIX / "company_HBL.html").read_text(encoding="utf-8")
UNKNOWN = (FIX / "company_UNKNOWN.html").read_text(encoding="utf-8")
REAL_MW = (FIX / "market_watch.html").read_text(encoding="utf-8")


# ------------------------------------------------------------------ parser: real HBL page
@pytest.fixture(scope="module")
def hbl():
    return P.parse_company_page(HBL, "HBL")


def test_profile_fields(hbl):
    assert hbl["company_name"] == "Habib Bank Limited"
    assert hbl["sector"] == "COMMERCIAL BANKS"
    assert hbl["business_description"].startswith("Habib Bank Limited is incorporated in Pakistan")
    assert hbl["website"] == "http://www.hbl.com"
    assert hbl["fiscal_year_end"] == "December"
    assert hbl["auditor"].startswith("A.F. Ferguson")
    assert [p["role"] for p in hbl["key_people"]] == ["CEO", "Chairperson", "Company Secretary"]


def test_equity_and_quote_fields(hbl):
    assert hbl["market_cap_pkr"] == 466_679_125_420.0  # page shows PKR thousands
    assert hbl["shares"] == 1_466_852_508
    assert hbl["free_float"] == 586_741_003 and hbl["free_float_pct"] == 40.0
    assert hbl["price"] == 318.15 and hbl["ldcp"] == 305.91
    assert hbl["pe_ratio_ttm"] == 7.43
    assert (hbl["week52_low"], hbl["week52_high"]) == (197.6, 369.99)
    assert hbl["price_as_of"].startswith("Mon, Jul 6, 2026")


def test_financials_and_ratios(hbl):
    ann = hbl["financials"]["annual"]
    assert ann["periods"] == ["2025", "2024", "2023", "2022"]
    assert ann["rows"]["EPS"]["2025"] == 42.60
    assert ann["rows"]["Profit after Taxation"]["2024"] == 56_765_819.0
    assert hbl["financials"]["quarterly"]["periods"][0] == "Q1 2026"
    r = hbl["ratios"]["rows"]
    assert r["EPS Growth (%)"]["2024"] == -0.15  # "(0.15)" is negative
    assert r["PEG"]["2023"] == 0.03
    h = hbl["headline_annual"]
    assert (h["period"], h["eps"], h["net_profit"]) == ("2025", 42.6, 62_492_417.0)
    assert (h["revenue_label"], h["revenue"]) == ("Mark-up Earned", 634_895_672.0)


def test_unknown_symbol_page_is_rejected():
    with pytest.raises(P.UnknownSymbol):
        P.parse_company_page(UNKNOWN, "ZZZZINVALID")


# ------------------------------------------------------------------ parser: helpers + constituents
@pytest.mark.parametrize("raw,expected", [
    ("1,234.50", 1234.5), ("(0.15)", -0.15), ("12.5%", 12.5), ("Rs.318.15", 318.15),
    ("-", None), ("", None), ("N/A", None), (None, None), ("abc", None), ("-3.2", -3.2),
])
def test_parse_number(raw, expected):
    assert P.parse_number(raw) == expected


def test_parse_range():
    assert P.parse_range("197.6 \u2014 369.99") == (197.6, 369.99)
    assert P.parse_range("0.0 / 0.0") == (0.0, 0.0)
    assert P.parse_range("") == (None, None)


def test_real_market_watch_fixture():
    syms = [m["symbol"] for m in P.kse100_from_market_watch(REAL_MW)]
    assert "CNERGY" in syms and "KEL" in syms


def test_kse100_exact_token_match():
    """'KSE100PR' (price-return index) must not be mistaken for KSE100."""
    html = REAL_MW.replace("ALLSHR,JSMFI,KMIALLSHR,KSE100,KSE100PR", "ALLSHR,KSE100PR", 1)
    syms = [m["symbol"] for m in P.kse100_from_market_watch(html)]
    assert "CNERGY" not in syms


def test_layout_change_is_loud():
    with pytest.raises(P.ScraperError):
        P.kse100_from_market_watch("<html><body><p>maintenance</p></body></html>")
    with pytest.raises(P.ScraperError):
        P.kse100_from_market_watch("<table><thead><tr><th>SYMBOL</th></tr></thead></table>")


# ------------------------------------------------------------------ mock PSX server
def market_watch_html(n=100, extra_non_kse=3, pr_only=2):
    head = re.search(r"<thead.*?</thead>", REAL_MW, re.S).group(0)
    row = ('<tr><td data-order="{s}" data-search="{s}"><a class="tbl__symbol" data-title="{s} Ltd" '
           'href="/company/{s}"><strong>{s}</strong></a></td><td>0825</td><td>{listed}</td>'
           + '<td class="right">1</td>' * 8 + "</tr>")
    rows = [row.format(s=f"S{i:03d}", listed="ALLSHR,KSE100,KSE100PR") for i in range(1, n + 1)]
    rows += [row.format(s=f"N{i}", listed="ALLSHR") for i in range(extra_non_kse)]
    rows += [row.format(s=f"PR{i}", listed="KSE100PR") for i in range(pr_only)]
    return f"<html><body><table>{head}<tbody>{''.join(rows)}</tbody></table></body></html>"


class MockPSX:
    def __init__(self):
        self.hits: dict[str, int] = {}
        self.times: list[tuple[float, str]] = []
        self.behaviour: dict[str, list] = {}  # path -> list of codes to serve in order, then 200
        self.mw = market_watch_html()
        outer = self

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *a):
                pass

            def do_GET(self):
                path = self.path
                outer.hits[path] = outer.hits.get(path, 0) + 1
                outer.times.append((time.monotonic(), path))
                queue = outer.behaviour.get(path)
                code = queue.pop(0) if queue else 200
                body, ctype = b"", "text/html"
                if code == 200:
                    if path == "/market-watch":
                        body = outer.mw.encode()
                    elif path == "/company/GONE":
                        code = 404
                    elif path == "/company/NOTREAL":
                        body = UNKNOWN.encode()
                    elif path.startswith("/company/"):
                        body = HBL.encode()
                    else:
                        code = 404
                self.send_response(code)
                if code == 503:
                    self.send_header("Retry-After", "1")
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"
        threading.Thread(target=lambda: self.server.serve_forever(poll_interval=0.01), daemon=True).start()

    def company_requests(self):
        return sum(v for k, v in self.hits.items() if k.startswith("/company/"))

    def close(self):
        self.server.shutdown()


@pytest.fixture
def psx():
    m = MockPSX()
    yield m
    m.close()


def make_client(psx, tmp_path, **kw):
    delays: list[float] = []
    defaults = dict(base_url=psx.url, cache_dir=tmp_path / "cache", min_interval=0, jitter=0,
                    backoff_base=5.0, sleep=lambda s: delays.append(s))
    defaults.update(kw)
    c = P.PoliteClient(**defaults)
    c.recorded_delays = delays
    return c


def run(psx, tmp_path, client=None, **kw):
    client = client or make_client(psx, tmp_path)
    return P.run_daily(out_dir=tmp_path / "out", cache_dir=tmp_path / "cache", client=client, **kw)


# ------------------------------------------------------------------ run behaviour
def test_full_run_makes_one_request_per_stock_plus_one(psx, tmp_path):
    res = run(psx, tmp_path)
    assert res["meta"]["status"] == "complete"
    assert res["meta"]["stocks_ok"] == 100  # non-KSE100 and KSE100PR-only rows excluded
    assert res["meta"]["requests_made"] == 101
    out = tmp_path / "out"
    date = res["meta"]["date"]
    assert (out / "kse100_latest.json").exists()
    data = json.loads((out / f"kse100_fundamentals_{date}.json").read_text())
    assert data["stocks"][0]["headline_annual"]["eps"] == 42.6
    assert "total_assets" in data["meta"]["not_available_on_psx"]
    rows = list(csv.DictReader(open(out / f"kse100_fundamentals_{date}.csv", encoding="utf-8-sig")))
    assert len(rows) == 100 and rows[0]["eps"] == "42.6" and rows[0]["net_profit_margin_pct"] == "9.84"


def test_second_run_same_day_costs_zero_requests(psx, tmp_path):
    run(psx, tmp_path)
    before = sum(psx.hits.values())
    res = run(psx, tmp_path)  # fresh client, same cache dir = also how a crashed run resumes
    assert res["meta"]["requests_made"] == 0 and res["meta"]["cache_hits"] == 101
    assert sum(psx.hits.values()) == before


def test_testing_mode_does_not_overwrite_latest(psx, tmp_path):
    res = run(psx, tmp_path, limit=3)
    assert res["meta"]["stocks_ok"] == 3 and res["meta"]["requests_made"] == 4
    assert not (tmp_path / "out" / "kse100_latest.json").exists()


def test_specific_symbols_mode(psx, tmp_path):
    res = run(psx, tmp_path, only_symbols=["s005", "S010"])
    assert [s["symbol"] for s in res["stocks"]] == ["S005", "S010"]


def test_transient_500_is_retried_with_backoff(psx, tmp_path):
    psx.behaviour["/company/S001"] = [500, 502]
    c = make_client(psx, tmp_path)
    res = run(psx, tmp_path, client=c, limit=2)
    assert res["meta"]["status"] == "complete"
    assert psx.hits["/company/S001"] == 3
    assert len(c.recorded_delays) == 2 and c.recorded_delays[0] >= 5 and c.recorded_delays[1] >= 15


def test_retry_after_header_is_honoured(psx, tmp_path):
    psx.behaviour["/company/S001"] = [503]
    c = make_client(psx, tmp_path, backoff_base=30)
    run(psx, tmp_path, client=c, limit=1)
    assert 1 <= c.recorded_delays[0] < 5  # Retry-After: 1, not the 30s base


def test_429_stops_the_run_and_is_never_retried(psx, tmp_path):
    psx.behaviour["/company/S003"] = [429]
    res = run(psx, tmp_path)
    assert res["meta"]["status"] == "aborted"
    assert psx.hits["/company/S003"] == 1  # no retry
    assert "/company/S004" not in psx.hits  # nothing after the rejection
    assert res["meta"]["stocks_ok"] == 2  # earlier work is kept
    date = res["meta"]["date"]
    assert (tmp_path / "out" / f"kse100_fundamentals_{date}.json").exists()
    assert not (tmp_path / "out" / "kse100_latest.json").exists()  # bad run never becomes 'latest'


def test_403_also_stops_the_run(psx, tmp_path):
    psx.behaviour["/company/S002"] = [403]
    res = run(psx, tmp_path)
    assert res["meta"]["status"] == "aborted" and psx.hits["/company/S002"] == 1


def test_circuit_breaker_after_consecutive_failures(psx, tmp_path):
    for i in range(1, 11):
        psx.behaviour[f"/company/S{i:03d}"] = [500] * 3
    res = run(psx, tmp_path, client=make_client(psx, tmp_path, max_consecutive_failures=3))
    assert res["meta"]["status"] == "aborted"
    assert psx.company_requests() == 9  # 3 stocks x 3 attempts, then stop - not 10 x 3


def test_isolated_failure_does_not_stop_the_run(psx, tmp_path):
    psx.behaviour["/company/S002"] = [500] * 3
    res = run(psx, tmp_path, limit=4)
    assert res["meta"]["status"] == "partial"
    assert res["meta"]["stocks_ok"] == 3 and res["errors"][0]["symbol"] == "S002"


def test_delisted_and_invalid_pages_are_recorded_not_fatal(psx, tmp_path):
    res = run(psx, tmp_path, only_symbols=["S001", "GONE", "NOTREAL", "S002"])
    assert res["meta"]["stocks_ok"] == 2 and res["meta"]["status"] == "partial"
    assert {e["symbol"] for e in res["errors"]} == {"GONE", "NOTREAL"}


def test_request_budget_fuse(psx, tmp_path):
    res = run(psx, tmp_path, client=make_client(psx, tmp_path, max_requests=5))
    assert res["meta"]["status"] == "aborted" and sum(psx.hits.values()) == 5


def test_bad_node_404_on_market_watch_is_retried_on_fresh_connection(psx, tmp_path):
    psx.behaviour["/market-watch"] = [404, 404]
    res = run(psx, tmp_path, limit=1)
    assert res["meta"]["status"] == "complete" and psx.hits["/market-watch"] == 3


def test_requests_are_spaced_by_min_interval(psx, tmp_path):
    c = make_client(psx, tmp_path, min_interval=0.25, jitter=0, sleep=time.sleep)
    run(psx, tmp_path, client=c, limit=4)
    t = [x[0] for x in psx.times]
    gaps = [b - a for a, b in zip(t, t[1:])]
    assert len(gaps) == 4 and min(gaps) >= 0.22


def test_refuses_to_write_when_universe_looks_wrong(psx, tmp_path):
    psx.mw = market_watch_html(n=12)
    with pytest.raises(P.ScraperError, match="expected ~100"):
        run(psx, tmp_path)
    assert not (tmp_path / "out").exists()


def test_overlapping_runs_are_refused(psx, tmp_path):
    lock = tmp_path / "cache" / "run.lock"
    lock.parent.mkdir(parents=True)
    lock.write_text("123")
    with pytest.raises(P.ScraperError, match="another run"):
        run(psx, tmp_path)


def test_user_agent_is_honest_and_not_rotated(psx, tmp_path):
    c = make_client(psx, tmp_path)
    assert "psx-kse100-scraper" in c.session.headers["User-Agent"]
    assert "python-requests" not in c.session.headers["User-Agent"]
